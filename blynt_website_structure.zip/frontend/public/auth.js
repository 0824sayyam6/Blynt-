/*
  auth.js — Frontend authentication helpers and form validation for Blynt
  - Client-side validation for login and registration forms
  - Admin quick-check (demo): fixed credentials (admin cannot register)
  - Helper to POST to server endpoints (/api/auth/login, /api/auth/register)
  - Shows inline messages, supports CSRF token header, simple client-side rate-limit
  - Exposes window.BlyntAuth API for other scripts to reuse

  Usage:
    BlyntAuth.bindLoginForm(document.getElementById('loginForm'), { onSuccess: (role)=>{ window.location = '/'; } });
    BlyntAuth.bindRegisterForm(document.getElementById('registerForm'), { onSuccess: ()=>{ window.location = '/login'; } });

  Security note: never store real admin credentials on the client in production. The admin demo credentials are only for local/demo use.
*/

(function(window, document){
  'use strict';

  const ADMIN = { email: 'Blynt321@gmail.com', password: '8724166shabbir' };
  const LOGIN_ENDPOINT = '/api/auth/login';
  const REGISTER_ENDPOINT = '/api/auth/register';

  // Simple client-side rate limiting per form (prevents brute force from a single browser session)
  const RateLimiter = {
    attempts: {},
    maxAttempts: 8,
    windowMs: 15 * 60 * 1000, // 15 minutes
    hit(key){ const now = Date.now(); if(!this.attempts[key]) this.attempts[key]=[]; this.attempts[key].push(now); this.attempts[key]= this.attempts[key].filter(t=> now - t <= this.windowMs); return this.attempts[key].length; },
    isBlocked(key){ return this.attempts[key] && this.attempts[key].length >= this.maxAttempts; }
  };

  // Validation helpers
  function isValidEmail(email){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email||'').trim()); }
  function isStrongPassword(pw){ return typeof pw === 'string' && pw.length >= 8; } // simple rule; replace with zxcvbn if desired

  // DOM helpers for messages
  function setMessage(el, text, ok){ if(!el) return; el.textContent = text || ''; el.style.color = ok ? 'green' : '#b22222'; }

  // Fetch helper with optional CSRF token support
  async function postJson(url, payload, opts={}){
    const headers = Object.assign({'Content-Type':'application/json'}, opts.headers||{});
    if(opts.csrfToken) headers['X-CSRF-Token'] = opts.csrfToken;
    const res = await fetch(url, { method: 'POST', headers, credentials: opts.credentials||'same-origin', body: JSON.stringify(payload) });
    return res;
  }

  // Bind login form behavior
  function bindLoginForm(formEl, config={}){
    if(!formEl) throw new Error('login form element required');
    const msgEl = formEl.querySelector('.message') || formEl.querySelector('#msg') || createMessageEl(formEl);

    // handle submit
    formEl.addEventListener('submit', async (e)=>{
      e.preventDefault(); setMessage(msgEl, '');
      const role = (formEl.querySelector('[name="role"]') || {}).value || 'customer';
      const email = (formEl.querySelector('[name="email"]') || {}).value||'';
      const password = (formEl.querySelector('[name="password"]') || {}).value||'';

      // rate limit
      const key = 'login:'+role+':'+(email||'');
      if(RateLimiter.isBlocked(key)){ setMessage(msgEl, 'Too many attempts. Try again later.', false); return; }
      RateLimiter.hit(key);

      if(!email || !password){ setMessage(msgEl, 'Please provide email and password', false); return; }
      if(!isValidEmail(email)){ setMessage(msgEl, 'Please enter a valid email', false); return; }

      // Admin quick-check (demo only)
      if(role === 'admin'){
        if(email.toLowerCase() === ADMIN.email.toLowerCase() && password === ADMIN.password){ setMessage(msgEl, 'Admin signed in (demo). Redirecting...'); if(typeof config.onSuccess === 'function') setTimeout(()=>config.onSuccess('admin'), 600); else setTimeout(()=> window.location = '/admin/dashboard', 600); return; }
        else{ setMessage(msgEl, 'Invalid admin credentials', false); return; }
      }

      // call server for seller/customer
      try{
        const res = await postJson(config.loginEndpoint||LOGIN_ENDPOINT, { role, email, password }, { csrfToken: config.csrfToken });
        if(!res.ok){ const text = await res.text(); throw new Error(text || ('Server returned '+res.status)); }
        const data = await res.json();
        if(data && data.success){ setMessage(msgEl, 'Signed in. Redirecting...'); if(typeof config.onSuccess==='function') setTimeout(()=>config.onSuccess(role, data), 600); else setTimeout(()=>{ if(role==='seller') window.location='/seller/dashboard'; else window.location='/customer/dashboard'; }, 600); }
        else setMessage(msgEl, data && data.message ? data.message : 'Sign in failed', false);
      }catch(err){ console.error('Login error', err); setMessage(msgEl, 'Sign in failed: '+err.message, false); }
    });

    return { formEl };
  }

  // Bind register form behavior
  function bindRegisterForm(formEl, config={}){
    if(!formEl) throw new Error('register form element required');
    const msgEl = formEl.querySelector('.message') || createMessageEl(formEl);

    formEl.addEventListener('submit', async (e)=>{
      e.preventDefault(); setMessage(msgEl, '');
      const role = (formEl.querySelector('[name="role"]') || {}).value || 'customer';
      const email = (formEl.querySelector('[name="email"]') || {}).value||'';
      const password = (formEl.querySelector('[name="password"]') || {}).value||'';
      const confirm = (formEl.querySelector('[name="confirm"]') || {}).value||'';
      const agreement = (formEl.querySelector('[name="agreement"]') || {}).checked;

      if(role === 'admin'){ setMessage(msgEl, 'Admin cannot register. Use Admin sign in.', false); return; }
      if(!email || !password || !confirm){ setMessage(msgEl, 'Please fill all required fields', false); return; }
      if(!isValidEmail(email)){ setMessage(msgEl, 'Please use a valid email', false); return; }
      if(password !== confirm){ setMessage(msgEl, 'Passwords do not match', false); return; }
      if(!isStrongPassword(password)){ setMessage(msgEl, 'Password should be at least 8 characters', false); return; }
      if(!agreement){ setMessage(msgEl, 'You must agree to Terms & Privacy', false); return; }

      // rate limit
      const key = 'register:'+role+':'+email;
      if(RateLimiter.isBlocked(key)){ setMessage(msgEl, 'Too many attempts. Try again later.', false); return; }
      RateLimiter.hit(key);

      try{
        const res = await postJson(config.registerEndpoint||REGISTER_ENDPOINT, { role, email, password }, { csrfToken: config.csrfToken });
        if(!res.ok){ const t = await res.text(); throw new Error(t || ('Server returned '+res.status)); }
        const data = await res.json();
        setMessage(msgEl, (data && data.message) || 'Registration successful. Please check email to verify.');
        if(typeof config.onSuccess === 'function') setTimeout(()=>config.onSuccess(data), 900);
        else setTimeout(()=> window.location = '/login', 900);
      }catch(err){ console.error('Register error', err); setMessage(msgEl, 'Registration failed: '+err.message, false); }
    });

    return { formEl };
  }

  function createMessageEl(formEl){ const el = document.createElement('div'); el.className='message'; el.style.minHeight='20px'; formEl.appendChild(el); return el; }

  // Small utility: auto-bind forms with data attributes
  function autoBind(){
    // login
    const lf = document.querySelector('form[data-blynt-login]'); if(lf) bindLoginForm(lf);
    const rf = document.querySelector('form[data-blynt-register]'); if(rf) bindRegisterForm(rf);
  }

  // Expose API
  const BlyntAuth = {
    bindLoginForm,
    bindRegisterForm,
    validateEmail:isValidEmail,
    validatePassword:isStrongPassword,
    adminCredentials: ADMIN,
    RateLimiter
  };

  window.BlyntAuth = BlyntAuth;

  // auto init on DOM ready
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', autoBind); else autoBind();

})(window, document);
