/*
  database.js — Blynt database connection and query utilities using Knex

  - Supports PostgreSQL (recommended) or SQLite (dev) depending on environment variables.
  - Provides initialization, migrations (simple schema creation), and common queries used by the server.

  Installation:
    npm install knex pg sqlite3

  Usage:
    const DB = require('./database');
    await DB.init();
    await DB.migrate();
    const user = await DB.createUser({ role:'customer', email:'a@b.com', passwordHash:'hash' });

  Configuration (via environment variables):
    DB_CLIENT=pg           # or sqlite3
    PG_CONNECTION=postgres://user:pass@host:5432/dbname  # if using pg
    SQLITE_FILE=./data/blynt.sqlite

  Notes:
    - In production use PostgreSQL (set DB_CLIENT=pg). For local development sqlite3 is convenient.
    - This module handles simple password storage as provided; integrate bcrypt in your server code before calling createUser.
    - The migration function is idempotent (creates tables if they don't exist).
*/

const knex = require('knex');
const path = require('path');

const CLIENT = process.env.DB_CLIENT || (process.env.PG_CONNECTION ? 'pg' : 'sqlite3');

let db = null;

async function init(){
  if(db) return db;
  const common = { pool: { min: 0, max: 10 } };
  if(CLIENT === 'pg'){
    const conn = process.env.PG_CONNECTION || process.env.DATABASE_URL;
    if(!conn) throw new Error('PG_CONNECTION or DATABASE_URL must be set when DB_CLIENT=pg');
    db = knex(Object.assign({ client: 'pg', connection: conn }, common));
  } else {
    const file = process.env.SQLITE_FILE || path.join(__dirname, 'data', 'blynt.sqlite');
    db = knex(Object.assign({ client: 'sqlite3', connection: { filename: file }, useNullAsDefault: true }, common));
  }
  return db;
}

async function migrate(){
  const k = await init();
  // users
  const hasUsers = await k.schema.hasTable('users');
  if(!hasUsers){
    await k.schema.createTable('users', t=>{
      t.string('id').primary();
      t.string('role').notNullable(); // customer, seller, admin
      t.string('email').notNullable().unique();
      t.string('password_hash').notNullable();
      t.string('name');
      t.timestamps(true,true);
    });
  }

  // categories
  const hasCategories = await k.schema.hasTable('categories');
  if(!hasCategories){
    await k.schema.createTable('categories', t=>{
      t.string('id').primary();
      t.string('title').notNullable();
      t.text('description');
      t.string('image_url');
      t.timestamps(true,true);
    });
  }

  // products
  const hasProducts = await k.schema.hasTable('products');
  if(!hasProducts){
    await k.schema.createTable('products', t=>{
      t.string('id').primary();
      t.string('seller_id').notNullable().references('id').inTable('users');
      t.string('title').notNullable();
      t.text('description');
      t.decimal('price', 12, 2).notNullable().defaultTo(0);
      t.integer('stock').defaultTo(0);
      t.string('sku');
      t.string('category_id');
      t.json('images');
      t.json('videos');
      t.json('shipping_countries');
      t.string('status').defaultTo('draft');
      t.string('visibility').defaultTo('public');
      t.timestamps(true,true);
    });
  }

  // orders
  const hasOrders = await k.schema.hasTable('orders');
  if(!hasOrders){
    await k.schema.createTable('orders', t=>{
      t.string('id').primary();
      t.string('user_id').notNullable().references('id').inTable('users');
      t.json('items');
      t.decimal('subtotal', 12, 2).defaultTo(0);
      t.decimal('discount', 12, 2).defaultTo(0);
      t.decimal('tax', 12, 2).defaultTo(0);
      t.decimal('shipping', 12, 2).defaultTo(0);
      t.decimal('total', 12, 2).defaultTo(0);
      t.string('status').defaultTo('pending');
      t.timestamp('paid_at');
      t.timestamps(true,true);
    });
  }

  // carts (optional persistence)
  const hasCarts = await k.schema.hasTable('carts');
  if(!hasCarts){
    await k.schema.createTable('carts', t=>{
      t.string('user_id').primary().references('id').inTable('users');
      t.json('payload');
      t.timestamp('updated_at').defaultTo(k.fn.now());
    });
  }

  return true;
}

// ---------- utility id generator ----------
const crypto = require('crypto');
function genId(prefix=''){ return prefix + crypto.randomBytes(8).toString('hex'); }

// ---------- users ----------
async function createUser({ role='customer', email, passwordHash, name='' }){
  if(!email || !passwordHash) throw new Error('email and passwordHash required');
  const k = await init();
  const id = genId('u_');
  await k('users').insert({ id, role, email, password_hash: passwordHash, name, created_at: k.fn.now(), updated_at: k.fn.now() });
  return getUserById(id);
}
async function getUserByEmail(email){ const k = await init(); return k('users').where({ email }).first(); }
async function getUserById(id){ const k = await init(); return k('users').where({ id }).first(); }
async function listUsers(){ const k = await init(); return k('users').select('*').orderBy('created_at','desc'); }

// ---------- categories ----------
async function createCategory({ title, description='', imageUrl=null }){ const k=await init(); const id=genId('cat_'); await k('categories').insert({ id, title, description, image_url: imageUrl, created_at:k.fn.now(), updated_at:k.fn.now() }); return getCategoryById(id); }
async function listCategories(){ const k=await init(); return k('categories').select('*').orderBy('title'); }
async function getCategoryById(id){ const k=await init(); return k('categories').where({ id }).first(); }

// ---------- products ----------
async function createProduct({ sellerId, title, description='', price=0, stock=0, sku='', categoryId=null, images=[], videos=[], shippingCountries=[], status='draft', visibility='public' }){
  const k = await init(); const id = genId('p_');
  await k('products').insert({ id, seller_id: sellerId, title, description, price, stock, sku, category_id: categoryId, images: JSON.stringify(images||[]), videos: JSON.stringify(videos||[]), shipping_countries: JSON.stringify(shippingCountries||[]), status, visibility, created_at: k.fn.now(), updated_at: k.fn.now() });
  return getProductById(id);
}
async function updateProduct(id, patch){ const k = await init(); const copy = Object.assign({}, patch); if(copy.images) copy.images = JSON.stringify(copy.images); if(copy.videos) copy.videos = JSON.stringify(copy.videos); if(copy.shipping_countries) copy.shipping_countries = JSON.stringify(copy.shipping_countries); copy.updated_at = k.fn.now(); await k('products').where({ id }).update(copy); return getProductById(id); }
async function getProductById(id){ const k = await init(); const p = await k('products').where({ id }).first(); if(!p) return null; // parse json fields
  try{ p.images = p.images ? JSON.parse(p.images) : []; p.videos = p.videos ? JSON.parse(p.videos) : []; p.shipping_countries = p.shipping_countries ? JSON.parse(p.shipping_countries) : []; }catch(e){ p.images = []; p.videos = []; p.shipping_countries = []; }
  return p;
}
async function listProducts({ limit=24, onlyPublished=true }={}){ const k = await init(); let q = k('products').select('*').orderBy('created_at','desc').limit(limit); if(onlyPublished) q = q.where({ status: 'published' }).andWhere('visibility','!=','private'); const rows = await q; return Promise.all(rows.map(r=>getProductById(r.id))); }

// ---------- carts ----------
async function saveCart(userId, payload){ const k = await init(); const row = { user_id: userId, payload: JSON.stringify(payload), updated_at: k.fn.now() }; const exists = await k('carts').where({ user_id: userId }).first(); if(exists) await k('carts').where({ user_id: userId }).update(row); else await k('carts').insert(row); return true; }
async function loadCart(userId){ const k = await init(); const r = await k('carts').where({ user_id: userId }).first(); if(!r) return null; try{ return JSON.parse(r.payload); } catch(e){ return null; } }

// ---------- orders ----------
async function createOrder({ userId, items, subtotal=0, discount=0, tax=0, shipping=0, total=0, status='pending' }){
  const k = await init(); const id = genId('o_'); await k('orders').insert({ id, user_id: userId, items: JSON.stringify(items||[]), subtotal, discount, tax, shipping, total, status, created_at: k.fn.now(), updated_at: k.fn.now() }); return getOrderById(id);
}
async function getOrderById(id){ const k = await init(); const o = await k('orders').where({ id }).first(); if(!o) return null; try{ o.items = o.items ? JSON.parse(o.items) : []; }catch(e){ o.items = []; } return o; }
async function setOrderPaid(id){ const k = await init(); await k('orders').where({ id }).update({ status: 'paid', paid_at: k.fn.now(), updated_at: k.fn.now() }); return getOrderById(id); }
async function listOrders(){ const k = await init(); const rows = await k('orders').select('*').orderBy('created_at','desc'); return Promise.all(rows.map(r=>getOrderById(r.id))); }

// ---------- utilities ----------
async function close(){ if(db) { await db.destroy(); db = null; } }

module.exports = {
  init,
  migrate,
  // users
  createUser,
  getUserByEmail,
  getUserById,
  listUsers,
  // categories
  createCategory,
  listCategories,
  getCategoryById,
  // products
  createProduct,
  updateProduct,
  getProductById,
  listProducts,
  // carts
  saveCart,
  loadCart,
  // orders
  createOrder,
  getOrderById,
  setOrderPaid,
  listOrders,
  // lifecycle
  close
};
