const controller = new AbortController();
BlyntUpload.upload({ images: inst.images, videos: inst.videos }, '/api/seller/products/upload', (loaded, total)=>{ console.log('progress', loaded, total); }, controller.signal)
  .then(res=>console.log('uploaded', res))
  .catch(err=>console.error(err));
