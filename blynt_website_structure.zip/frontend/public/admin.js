/*
  admin.js — Admin dashboard logic and profit calculation for Blynt
  - Fetches orders and products from API endpoints and computes sales metrics
  - Admin profit share: fixed 8% of every sold item's gross (price * qty)
  - Provides utilities: totals, profits, top sellers, time-window filtering, CSV export
  - Exposes global AdminApp for integration with admin HTML pages

  Usage (example):
    <script src="/assets/admin.js"></script>
    <script>
      AdminApp.init({ apiBase: '/api', selectors: { totalSales: '#totalSales', adminProfit: '#adminProfit', ordersTable: '#ordersTable' } });
    </script>
*/
(function(window, document){
  'use strict';

  const DEFAULTS = { apiBase: '/api', adminCutPct: 0.08, ordersEndpoint: '/admin/orders', productsEndpoint: '/admin/products' };

  function fmt(n, currency='$'){ return currency + Number(n||0).toFixed(2); }
  function now(){ return new Date().toISOString(); }

  // Basic fetch wrapper
  async function apiGET(path){
    const res = await fetch(path, { credentials: 'same-origin' });
    if(!res.ok) throw new Error('API error: '+res.status);
    return res.json();
  }

  // Compute metrics from orders array
  // orders: [{ id, items: [{id,title,price,qty}], subtotal, tax, shipping, total, status, createdAt }]
  function computeMetrics(orders, adminCutPct){
    const metrics = { totalOrders: 0, grossSales: 0, adminProfit: 0, platformShare: 0, sellerPayout: 0, ordersByStatus: {}, itemsSold: {}, topSellers: {} };
    metrics.totalOrders = orders.length;

    orders.forEach(order => {
      // skip non-paid orders if needed; include all orders by default but mark status
      metrics.ordersByStatus[order.status] = (metrics.ordersByStatus[order.status] || 0) + 1;

      const items = order.items || [];
      let orderGross = 0;
      items.forEach(it => {
        const price = Number(it.price || 0);
        const qty = Number(it.qty || 0) || 0;
        const line = price * qty;
        orderGross += line;

        // track items sold
        const key = it.id || it.sku || it.title || JSON.stringify(it);
        metrics.itemsSold[key] = metrics.itemsSold[key] || { title: it.title || key, qty: 0, revenue: 0 };
        metrics.itemsSold[key].qty += qty;
        metrics.itemsSold[key].revenue += line;

        // seller tracking (if seller info available in item metadata)
        const sellerId = (it.sellerId || it.seller || it.metadata && it.metadata.sellerId);
        if(sellerId){ metrics.topSellers[sellerId] = metrics.topSellers[sellerId] || { sellerId, revenue:0, qty:0 }; metrics.topSellers[sellerId].revenue += line; metrics.topSellers[sellerId].qty += qty; }
      });

      metrics.grossSales += orderGross;
      const adminCut = orderGross * adminCutPct;
      metrics.adminProfit += adminCut;
      metrics.sellerPayout += (orderGross - adminCut);
    });

    metrics.platformShare = metrics.adminProfit; // alias
    // convert itemsSold to sorted array
    metrics.topItems = Object.keys(metrics.itemsSold).map(k => Object.assign({ key:k }, metrics.itemsSold[k]));
    metrics.topItems.sort((a,b) => b.qty - a.qty || b.revenue - a.revenue);
    // top sellers array
    metrics.topSellersArr = Object.keys(metrics.topSellers).map(k => metrics.topSellers[k]).sort((a,b) => b.revenue - a.revenue);

    return metrics;
  }

  // Simple DOM render helpers
  function renderNumber(selector, text){ const el = document.querySelector(selector); if(el) el.textContent = text; }

  function renderOrdersTable(selector, orders){
    const wrap = document.querySelector(selector);
    if(!wrap) return;
    // build table HTML
    const headers = ['Order ID','Status','Items','Subtotal','Tax','Shipping','Total','Created At'];
    let html = '<table style="width:100%;border-collapse:collapse"><thead><tr>' + headers.map(h=>`<th style="text-align:left;padding:8px;border-bottom:1px solid #eee">${h}</th>`).join('') + '</tr></thead><tbody>';
    orders.forEach(o=>{
      const itemsDesc = (o.items || []).map(it=>`${escapeHtml(it.title||it.id)} × ${it.qty || 0}`).join('<br>');
      html += `<tr><td style="padding:8px;border-bottom:1px solid #fafafa">${escapeHtml(o.id)}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${escapeHtml(o.status)}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${itemsDesc}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${fmt(o.subtotal)}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${fmt(o.tax)}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${fmt(o.shipping)}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${fmt(o.total)}</td><td style="padding:8px;border-bottom:1px solid #fafafa">${escapeHtml(o.createdAt || '')}</td></tr>`;
    });
    html += '</tbody></table>';
    wrap.innerHTML = html;
  }

  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  // CSV export
  function ordersToCSV(orders){
    const cols = ['orderId','status','itemId','itemTitle','itemQty','itemPrice','lineTotal','subtotal','tax','shipping','total','createdAt'];
    const rows = [];
    orders.forEach(o=>{
      (o.items||[]).forEach(it=>{
        rows.push([o.id,o.status,it.id||'',it.title||'',it.qty||0,it.price||0,(it.price||0)*(it.qty||0),o.subtotal||0,o.tax||0,o.shipping||0,o.total||0,o.createdAt||'']);
      });
    });
    const csv = [cols.join(',')].concat(rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(','))).join('\n');
    return csv;
  }

  // Download helper
  function download(filename, content, mime='text/csv'){
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  // Public API
  const AdminApp = {
    options: Object.assign({}, DEFAULTS),
    orders: [],

    async init(config = {}){
      this.options = Object.assign({}, this.options, config || {});
      this.options.ordersEndpoint = (this.options.apiBase || DEFAULTS.apiBase) + (this.options.ordersEndpoint || DEFAULTS.ordersEndpoint);
      try{
        await this.loadOrders();
        this.render();
        return this;
      }catch(err){ console.error('AdminApp init failed', err); throw err; }
    },

    async loadOrders(){
      const url = this.options.ordersEndpoint;
      const data = await apiGET(url);
      // accept either { orders: [...] } or array
      this.orders = Array.isArray(data) ? data : (data.orders || []);
      return this.orders;
    },

    compute(){
      const metrics = computeMetrics(this.orders, this.options.adminCutPct);
      this.metrics = metrics;
      return metrics;
    },

    render(selectors = {}){
      // selectors: { totalSales, adminProfit, sellerPayout, ordersTable }
      const s = Object.assign({}, selectors, this.options.selectors || {});
      const metrics = this.compute();
      if(s.totalSales) renderNumber(s.totalSales, fmt(metrics.grossSales));
      if(s.adminProfit) renderNumber(s.adminProfit, fmt(metrics.adminProfit));
      if(s.sellerPayout) renderNumber(s.sellerPayout, fmt(metrics.sellerPayout));
      if(s.ordersTable) renderOrdersTable(s.ordersTable, this.orders);
      // additional render: top items and sellers
      if(s.topItems){ const el = document.querySelector(s.topItems); if(el){ el.innerHTML = metrics.topItems.slice(0,10).map(i=>`<div>${escapeHtml(i.title)} — qty: ${i.qty} — ${fmt(i.revenue)}</div>`).join(''); }}
      if(s.topSellers){ const el = document.querySelector(s.topSellers); if(el){ el.innerHTML = (metrics.topSellersArr||[]).slice(0,10).map(s=>`<div>${escapeHtml(s.sellerId)} — ${fmt(s.revenue)} — qty: ${s.qty}</div>`).join(''); }}
    },

    exportCSV(filename = `orders-${(new Date()).toISOString().slice(0,10)}.csv`){
      const csv = ordersToCSV(this.orders);
      download(filename, csv);
    },

    // reconcile order (admin action) — mark paid and compute admin profit
    async markOrderPaid(orderId){
      // server-side endpoint should exist to update order status and persist
      try{
        const res = await fetch((this.options.apiBase||DEFAULTS.apiBase) + `/admin/orders/${encodeURIComponent(orderId)}/mark-paid`, { method:'POST', credentials:'same-origin' });
        if(!res.ok) throw new Error('Mark paid failed');
        await this.loadOrders(); this.render();
        return true;
      }catch(err){ console.error(err); throw err; }
    }
  };

  // expose globally
  window.AdminApp = AdminApp;

  // auto-init if admin container present
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=>{ const el = document.querySelector('[data-admin-dashboard]'); if(el) AdminApp.init({ selectors: { totalSales: '#totalSales', adminProfit: '#adminProfit', sellerPayout: '#sellerPayout', ordersTable: '#ordersTable', topItems: '#topItems', topSellers: '#topSellers' } }).catch(()=>{}); });

})(window, document);
