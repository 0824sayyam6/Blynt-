/*
  payment.js — Blynt Payment Integration (PCI-compliant patterns)

  Purpose:
    - Provide safe, front-end helpers for integrating with card payment gateways using tokenization (Stripe Elements example and a generic tokenization flow).
    - IMPORTANT: Do NOT collect raw card numbers with your server or custom HTML inputs unless you are using a validated PCI integration. Use a gateway-provided client library (Elements/Hosted Fields) that returns a token or payment method id.

  What this file contains:
    - BlyntPayment.initStripe(publicKey, options) -> sets up Stripe Elements card UI and helpers
    - BlyntPayment.createPaymentIntent(amount, currency) -> calls your server to create a PaymentIntent (server endpoint required)
    - BlyntPayment.handleStripeCardPayment(clientSecret, onSuccess, onError) -> confirms card payment using Stripe.js
    - BlyntPayment.tokenizeCardGeneric(cardElementOrData) -> placeholder for other gateways that return a token
    - Utility functions and guidance for server endpoints

  Security / PCI notes (read carefully):
    - Never send raw PAN (card numbers) through your server directly. Use tokenization or redirect/hosted-pages provided by a PCI-compliant gateway (Stripe, Braintree, Adyen, PayPal, etc.).
    - This code expects server endpoints to create payment intents / tokens and to confirm/complete payments server-side where required.
    - Replace placeholder endpoints (/api/payments/create-intent, /api/payments/confirm) with your actual server routes.

  How to use (Stripe example):
    1) Include Stripe.js in your page: <script src="https://js.stripe.com/v3/"></script>
    2) Call BlyntPayment.initStripe('pk_test_...'); then mount card element to your chosen container.
    3) On checkout submit: call server endpoint to create a PaymentIntent, then call handleStripeCardPayment(clientSecret).

  Server endpoints required (examples):
    - POST /api/payments/create-intent  { amount, currency } -> { clientSecret }
    - POST /api/payments/confirm      { paymentIntentId } -> { success }

*/

;(function(window, document){
  'use strict';

  // ---------- Internal state ----------
  const state = {
    stripe: null,
    elements: null,
    cardElement: null,
    provider: null // 'stripe' or 'generic'
  };

  // ---------- Helpers ----------
  function qs(selector){ return document.querySelector(selector); }
  function el(id){ return document.getElementById(id); }
  function jsonPost(url, payload){ return fetch(url, { method:'POST', headers:{ 'Content-Type':'application/json' }, credentials:'same-origin', body: JSON.stringify(payload) }).then(r=>r.json()); }

  // ---------- Stripe Integration (recommended) ----------
  // Requires <script src="https://js.stripe.com/v3/"></script> on the page.
  async function initStripe(publicKey, options = {}){
    if(!publicKey) throw new Error('Stripe publicKey required');
    if(!window.Stripe) throw new Error('Stripe.js not loaded. Add <script src="https://js.stripe.com/v3/"></script>');
    state.stripe = window.Stripe(publicKey, options.stripeOptions || {});
    state.elements = state.stripe.elements();
    state.provider = 'stripe';
    return state;
  }

  // Mount card element into container selector (e.g. '#card-element')
  function mountStripeCard(selector, elementOptions = {}){
    if(state.provider !== 'stripe' || !state.elements) throw new Error('Stripe not initialized. Call initStripe first.');
    // default styles
    const style = Object.assign({ base: { color: '#0f172a', fontSize: '16px', '::placeholder': { color: '#6b7280' } }, invalid: { color: '#b22222' } }, elementOptions.style || {});
    const card = state.elements.create('card', Object.assign({ style }, elementOptions));
    card.mount(selector);
    state.cardElement = card;
    return card;
  }

  // Create a PaymentIntent by calling your server. Server must call gateway secret and return clientSecret.
  // Example server body: { amount: 1299, currency: 'usd', metadata: {...} }
  async function createPaymentIntent(amount, currency = 'usd', metadata = {}, endpoint = '/api/payments/create-intent'){
    if(typeof amount !== 'number' || amount <= 0) throw new Error('amount must be a positive number (in smallest currency unit)');
    const payload = { amount, currency, metadata };
    const res = await jsonPost(endpoint, payload);
    if(!res || !res.clientSecret) throw new Error('Invalid response from create-intent endpoint');
    return res.clientSecret;
  }

  // Confirm card payment (Stripe) using clientSecret from server
  // onSuccess receives paymentIntent, onError receives Error
  async function handleStripeCardPayment(clientSecret, onSuccess, onError){
    if(state.provider !== 'stripe' || !state.stripe) throw new Error('Stripe not initialized');
    if(!clientSecret) throw new Error('clientSecret required');
    if(!state.cardElement) throw new Error('Card element not mounted (call mountStripeCard)');

    try{
      const { error, paymentIntent } = await state.stripe.confirmCardPayment(clientSecret, { payment_method: { card: state.cardElement } });
      if(error){ if(typeof onError === 'function') onError(error); else throw error; }
      else { if(typeof onSuccess === 'function') onSuccess(paymentIntent); return paymentIntent; }
    }catch(err){ if(typeof onError === 'function') onError(err); else throw err; }
  }

  // ---------- Generic tokenization flow (for other gateways) ----------
  // Some gateways (Braintree, Adyen, Checkout.com) provide hosted fields or tokenization SDKs.
  // This function acts as a placeholder that expects a tokenization function to be provided by the gateway integration.
  async function tokenizeCardGeneric(tokenizeFn, cardData){
    // tokenizeFn should accept cardData (or rely on hosted fields) and return { token } or throw
    if(typeof tokenizeFn !== 'function') throw new Error('tokenizeFn required');
    const result = await tokenizeFn(cardData);
    if(!result || !result.token) throw new Error('tokenization failed');
    return result.token;
  }

  // Example: send token to server for charging
  async function chargeTokenOnServer(token, amount, currency='usd', endpoint = '/api/payments/charge-token'){
    if(!token) throw new Error('token required');
    const res = await jsonPost(endpoint, { token, amount, currency });
    return res;
  }

  // ---------- Webhook helper (server-side guidance) ----------
  // NOTE: webhook verification must be implemented on server using gateway docs. This is only a client-side helper note.
  function webhookGuidance(){
    return `Server must verify webhook signatures using gateway's secret. For example, Stripe uses Stripe-Signature and a signing secret. Use timing-safe comparisons and respond 200 quickly.`;
  }

  // ---------- Utilities: quick checkout flow (Stripe) ----------
  // High-level example combining steps. Caller responsible for UI/progress.
  async function stripeCheckoutFlow({ amount, currency='usd', createIntentEndpoint='/api/payments/create-intent', onSuccess, onError }){
    try{
      const clientSecret = await createPaymentIntent(amount, currency, {}, createIntentEndpoint);
      const pi = await handleStripeCardPayment(clientSecret, onSuccess, onError);
      return pi;
    }catch(err){ if(typeof onError==='function') onError(err); else throw err; }
  }

  // ---------- Expose public API ----------
  const BlyntPayment = {
    initStripe,
    mountStripeCard,
    createPaymentIntent,
    handleStripeCardPayment,
    stripeCheckoutFlow,
    tokenizeCardGeneric,
    chargeTokenOnServer,
    webhookGuidance
  };

  window.BlyntPayment = BlyntPayment;

})(window, document);
