const inst = BlyntUpload.init({
  imageInput: document.getElementById('imageInput'),
  imageDropzone: document.getElementById('imageUploader'),
  imagePreviewContainer: document.getElementById('imageThumbs'),
  videoInput: document.getElementById('videoInput'),
  videoDropzone: document.getElementById('videoUploader'),
  videoPreviewContainer: document.getElementById('videoThumbs'),
  callbacks: {
    onChange: ({images, videos})=>{ console.log('files changed', images.length, videos.length); },
    onError: (err)=>{ alert(err.message || err); }
  }
});
