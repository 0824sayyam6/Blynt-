// server.js
// Demo Express server for Blynt marketplace
// Run: node server.js
// Required env (create .env):
//   PORT=4000
//   ADMIN_EMAIL=Blynt321@gmail.com
//   ADMIN_PASSWORD=8724166shabbir
//   WEBHOOK_SECRET=your_webhook_shared_secret_here

require('dotenv').config();
const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');

const PORT = process.env.PORT || 4000;
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'Blynt321@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '8724166shabbir';
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || 'change_me';

// --- Simple in-memory stores (demo only) ---
const db = {
  users: [],          // { id, role: 'customer'|'seller'|'admin', email, passwordHash, name }
  categories: [],     // { id, title, description, imageUrl }
  products: [],       // { id, sellerId, title, price, description, images:[], videos:[], stock, ... }
  carts: {},          // { userId: { items: [...] } } (optional)
  orders: [],         // { id, userId, items, total, status, createdAt }
};

// create uploads folder for demo file storage
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// --- Multer setup (local storage for demo) ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '';
    const name = file.fieldname + '-' + Date.now() + '-' + Math.random().toString(36).slice(2,8) + ext;
    cb(null, name);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB per file limit
  fileFilter: (req, file, cb) => {
    // allow images and common video types
    const allowed = /jpeg|jpg|png|webp|gif|mp4|webm|quicktime/;
    if (!allowed.test(file.mimetype)) return cb(new Error('Unsupported file type: ' + file.mimetype));
    cb(null, true);
  }
});

// --- Express setup ---
const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// rate limiter (demo)
const limiter = rateLimit({ windowMs: 60 * 1000, max: 120 }); // 120 requests / minute
app.use(limiter);

// Serve uploads when requested (in production use CDN / signed URLs)
app.use('/uploads', express.static(UPLOAD_DIR));

// ---------- Helpers ----------
function generateId(prefix = '') { return prefix + crypto.randomBytes(6).toString('hex'); }
function now() { return new Date().toISOString(); }

// NOTE: demo password handling (plaintext) — replace with bcrypt/scrypt in production
function findUserByEmail(email) { return db.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase()); }
function createUser({ role, email, password, name }) {
  if (findUserByEmail(email)) throw new Error('Email already registered');
  const user = { id: generateId('u_'), role, email, passwordHash: password, name: name || '', createdAt: now() };
  db.users.push(user);
  return user;
}

// Middleware: simple demo auth using header x-demo-user or basic server-side admin check
function requireAdmin(req, res, next) {
  // For demo, allow admin if header x-admin-secret matches admin password OR if credentials match admin env
  const adminHeader = req.get('x-admin-secret');
  if (adminHeader && adminHeader === ADMIN_PASSWORD) return next();
  // fallback: check Basic Auth style header 'authorization: Basic <base64>'
  const auth = (req.headers.authorization || '');
  if (auth.startsWith('Basic ')) {
    try {
      const decoded = Buffer.from(auth.split(' ')[1], 'base64').toString();
      const [email, pass] = decoded.split(':');
      if (email === ADMIN_EMAIL && pass === ADMIN_PASSWORD) return next();
    } catch(e){}
  }
  return res.status(401).json({ error: 'admin auth required' });
}

// Middleware: demo auth for seller/customer endpoints
function requireSeller(req, res, next) {
  // demo: allow seller if header x-user-id points to existing seller
  const uid = req.get('x-user-id');
  if (!uid) return res.status(401).json({ error: 'missing x-user-id header' });
  const u = db.users.find(x => x.id === uid && x.role === 'seller');
  if (!u) return res.status(403).json({ error: 'seller role required' });
  req.currentUser = u;
  next();
}
function requireUser(req, res, next) {
  const uid = req.get('x-user-id');
  if (!uid) return res.status(401).json({ error: 'missing x-user-id header' });
  const u = db.users.find(x => x.id === uid);
  if (!u) return res.status(403).json({ error: 'user not found' });
  req.currentUser = u;
  next();
}

// ---------- API endpoints ----------

// Health
app.get('/api/health', (req, res) => res.json({ ok: true, ts: now() }));

// --- Auth: register & login ---
// Register (customer or seller). Admin is not allowed to register here.
app.post('/api/auth/register', (req, res) => {
  try {
    const { role, email, password } = req.body;
    if (!role || !email || !password) return res.status(400).json({ success: false, message: 'role, email and password are required' });
    if (role === 'admin') return res.status(400).json({ success: false, message: 'admin cannot register' });
    // basic validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ success: false, message: 'invalid email' });
    if (String(password).length < 6) return res.status(400).json({ success: false, message: 'password too short' });
    const user = createUser({ role, email, password, name: '' });
    // in production: send verification email, hash password
    return res.json({ success: true, userId: user.id, message: 'registered' });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message || 'register failed' });
  }
});

// Login (admin uses fixed creds)
app.post('/api/auth/login', (req, res) => {
  try {
    const { role, email, password } = req.body;
    if (!email || !password) return res.status(400).json({ success: false, message: 'email and password required' });
    // Admin: check against env fixed admin
    if (role === 'admin') {
      if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASSWORD) {
        return res.json({ success: true, role: 'admin', redirect: '/admin/dashboard' });
      } else return res.status(401).json({ success: false, message: 'invalid admin credentials' });
    }
    const user = findUserByEmail(email);
    if (!user || user.role !== role) return res.status(401).json({ success: false, message: 'invalid credentials' });
    // demo password check: plaintext comparison — replace with hashed check
    if (user.passwordHash !== password) return res.status(401).json({ success: false, message: 'invalid credentials' });
    // return user info, in production return session cookie or JWT token
    return res.json({ success: true, role: user.role, userId: user.id });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'login failed' });
  }
});

// --- Categories (admin) ---
// Create category
app.post('/api/categories', requireAdmin, upload.single('image'), (req, res) => {
  try {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ success: false, message: 'title required' });
    const imageUrl = req.file ? '/uploads/' + req.file.filename : null;
    const cat = { id: generateId('cat_'), title, description: description || '', imageUrl, createdAt: now() };
    db.categories.push(cat);
    return res.json({ success: true, category: cat });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// List categories (public)
app.get('/api/categories', (req, res) => {
  return res.json(db.categories);
});

// --- Seller product endpoints ---
// Create product (multipart form with images[] and videos[]). Seller must be authenticated via x-user-id header (demo)
app.post('/api/seller/products', requireSeller, upload.fields([{ name: 'images[]' }, { name: 'videos[]' }]), (req, res) => {
  try {
    const seller = req.currentUser;
    const body = req.body;
    // Accept common fields; body fields are strings (from form)
    const title = body.title || body.name;
    if (!title) return res.status(400).json({ success: false, message: 'title required' });
    const price = Number(body.price || 0);
    const stock = Number(body.stock || 0);
    const images = (req.files && req.files['images[]']) ? req.files['images[]'].map(f => '/uploads/' + f.filename) : [];
    const videos = (req.files && req.files['videos[]']) ? req.files['videos[]'].map(f => '/uploads/' + f.filename) : [];
    const prod = {
      id: generateId('p_'),
      sellerId: seller.id,
      title,
      price,
      description: body.description || '',
      images,
      videos,
      stock,
      sku: body.sku || '',
      category: body.category || '',
      tags: (body.tags || '').split(',').map(t => t.trim()).filter(Boolean),
      weight: body.weight || null,
      dimensions: body.dimensions || null,
      shippingCountries: (body.shippingCountries && (() => {
        try { return JSON.parse(body.shippingCountries); } catch(e) { return []; }
      })()) || [],
      status: body.status || 'draft',
      visibility: body.visibility || 'public',
      createdAt: now()
    };
    db.products.push(prod);
    return res.json({ success: true, product: prod });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: err.message || 'product save failed' });
  }
});

// Public product listing
app.get('/api/products', (req, res) => {
  const limit = parseInt(req.query.limit || '24', 10);
  // filter published & public (basic)
  const list = db.products.filter(p => p.status === 'published' && (p.visibility === 'public' || !p.visibility)).slice(0, limit);
  return res.json(list);
});

// Get single product
app.get('/api/products/:id', (req, res) => {
  const p = db.products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ success: false, message: 'product not found' });
  return res.json(p);
});

// --- Cart sync (store carts by userId for demo) ---
app.post('/api/cart/sync', requireUser, (req, res) => {
  const user = req.currentUser;
  const payload = req.body || {};
  db.carts[user.id] = { items: payload.items || [], coupon: payload.coupon || null, updatedAt: now() };
  return res.json({ success: true });
});

// --- Checkout (mock) ---
// Creates an order and returns either redirectUrl or orderId; also triggers a mock payment gateway process in real systems
app.post('/api/checkout', requireUser, (req, res) => {
  try {
    const user = req.currentUser;
    const { items, coupon } = req.body || {};
    if (!items || !Array.isArray(items) || items.length === 0) return res.status(400).json({ success: false, message: 'cart empty' });

    // compute totals basic
    const subtotal = items.reduce((s,it) => s + (Number(it.price||0) * Number(it.qty||0)), 0);
    const shipping = 5.0;
    const tax = subtotal * 0.12;
    let discount = 0;
    if (coupon) {
      if (coupon.type === 'percent') discount = subtotal * (Number(coupon.value||0)/100);
      else discount = Number(coupon.value||0);
    }
    const total = Math.max(0, subtotal - discount) + tax + shipping;

    // create order
    const order = { id: generateId('o_'), userId: user.id, items, subtotal, discount, tax, shipping, total, status: 'pending', createdAt: now() };
    db.orders.push(order);

    // Demo: return a redirectUrl to a mock payment page, or an orderId for server-side checkout
    // In production integrate with Stripe/PayPal etc. and return real redirect/paymentIntent info.
    return res.json({ success: true, orderId: order.id, redirectUrl: `/mock-pay?orderId=${order.id}` });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'checkout failed' });
  }
});

// Mock payment page (simple HTML) to simulate a payment provider and a webhook call
app.get('/mock-pay', (req, res) => {
  const { orderId } = req.query;
  const html = `
    <html><body style="font-family:Arial,Helvetica,sans-serif;padding:24px">
      <h2>Mock Payment Page</h2>
      <p>Order: ${orderId}</p>
      <form method="POST" action="/mock-pay/complete">
        <input type="hidden" name="orderId" value="${orderId}">
        <button type="submit">Simulate successful payment</button>
      </form>
    </body></html>
  `;
  res.send(html);
});

// Simulated payment completion: triggers webhook call to our /webhooks/payment endpoint (server-side POST)
app.post('/mock-pay/complete', express.urlencoded({ extended: true }), (req, res) => {
  const orderId = req.body.orderId;
  // find order
  const order = db.orders.find(o => o.id === orderId);
  if (!order) return res.status(404).send('Order not found');
  // mark paid locally (for demo)
  order.status = 'paid';
  // Build a webhook payload and signature (HMAC SHA256 using WEBHOOK_SECRET)
  const payload = JSON.stringify({ event: 'payment.succeeded', orderId: order.id, total: order.total, ts: now() });
  const signature = crypto.createHmac('sha256', WEBHOOK_SECRET).update(payload).digest('hex');
  // POST to webhook endpoint (server-to-server)
  const http = require('http');
  const options = { method: 'POST', hostname: 'localhost', port: PORT, path: '/webhooks/payment', headers: { 'Content-Type': 'application/json', 'x-signature': signature } };
  const req2 = http.request(options, (r) => {
    let data = ''; r.on('data', chunk => data += chunk); r.on('end', () => {
      res.send(`<p>Webhook triggered. Response: ${r.statusCode}</p><pre>${data}</pre>`);
    });
  });
  req2.on('error', (e) => res.status(500).send('Webhook call failed: '+e.message));
  req2.write(payload); req2.end();
});

// --- Payment webhook endpoint ---
// Verifies HMAC signature and processes events
app.post('/webhooks/payment', express.raw({ type: 'application/json' }), (req, res) => {
  try {
    const sig = req.headers['x-signature'] || '';
    const bodyBuf = req.body; // raw buffer
    const computed = crypto.createHmac('sha256', WEBHOOK_SECRET).update(bodyBuf).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(computed))) {
      console.warn('Webhook signature mismatch', sig, computed);
      return res.status(400).send('invalid signature');
    }
    const payload = JSON.parse(bodyBuf.toString('utf8'));
    // process events
    if (payload.event === 'payment.succeeded') {
      const order = db.orders.find(o => o.id === payload.orderId);
      if (order) {
        order.status = 'paid';
        order.paidAt = now();
      }
      // respond 200 quickly
      return res.json({ received: true });
    }
    // other events
    return res.json({ received: true, handled: false });
  } catch (err) {
    console.error('Webhook processing error', err);
    return res.status(500).send('webhook error');
  }
});

// --- Simple admin-only product listing for management ---
app.get('/api/admin/products', requireAdmin, (req, res) => {
  return res.json(db.products);
});

// --- Basic user listing (admin) ---
app.get('/api/admin/users', requireAdmin, (req, res) => {
  return res.json(db.users);
});

// --- Misc: list orders (admin) ---
app.get('/api/admin/orders', requireAdmin, (req, res) => {
  return res.json(db.orders);
});

// Fallback
app.use((req, res) => res.status(404).json({ success: false, message: 'not found' }));

// Start
app.listen(PORT, () => {
  console.log(`Blynt demo server running on http://localhost:${PORT}`);
  console.log(`Admin: ${ADMIN_EMAIL} (password from env)`);
});
