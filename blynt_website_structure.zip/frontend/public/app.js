/*
  app.js — Blynt Global Frontend Interactions & Cart Logic
  - Lightweight cart manager (localStorage-backed) with UI helper functions
  - Event delegation for `data-add-to-cart`, `data-remove-from-cart`, quantity controls
  - Helpers to sync cart with server, apply coupons, compute totals (subtotal, tax, shipping)
  - Exposes a global `window.BlyntApp` object for integration

  Usage notes:
  - Add "data-add-to-cart" attribute on Add buttons with JSON payload or product-id.
    Example: <button data-add-to-cart='{ "id":"p1","title":"Phone","price":299.99,"image":"/img.jpg" }'>Add</button>
    Or: <button data-add-to-cart data-product-id="p1">Add</button> (then supply product lookup via BlyntApp.registerProduct)

  - Cart UI container should have id="cart" or you can pass custom selectors to BlyntApp.init()
*/
(function (window, document) {
  'use strict';

  // ---------- Configuration ----------
  const STORAGE_KEY = 'blynt_cart_v1';
  const COUPON_STORAGE_KEY = 'blynt_coupon_v1';
  const DEFAULT_TAX_RATE = 0.12; // 12% example tax
  const DEFAULT_SHIPPING = 5.0; // flat shipping in USD (example)

  // ---------- Utilities ----------
  function now(){ return Date.now(); }
  function formatPrice(n, currency = '$'){ return currency + Number(n || 0).toFixed(2); }
  function clamp(n, min, max){ return Math.max(min, Math.min(max, n)); }

  // ---------- Cart model ----------
  const Cart = {
    items: [], // { id, title, price, qty, image, metadata }
    coupon: null, // { code, type: 'percent'|'fixed', value }

    load(){
      try{
        const raw = localStorage.getItem(STORAGE_KEY);
        const couponRaw = localStorage.getItem(COUPON_STORAGE_KEY);
        this.items = raw ? JSON.parse(raw) : [];
        this.coupon = couponRaw ? JSON.parse(couponRaw) : null;
      }catch(e){
        console.error('Failed to parse cart from storage', e);
        this.items = [];
        this.coupon = null;
      }
    },
    save(){
      try{
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.items));
        if(this.coupon) localStorage.setItem(COUPON_STORAGE_KEY, JSON.stringify(this.coupon));
        else localStorage.removeItem(COUPON_STORAGE_KEY);
      }catch(e){ console.error('Failed to save cart to storage', e); }
    },

    find(id){ return this.items.find(i => String(i.id) === String(id)); },

    add(product, qty = 1){
      if(!product || !product.id) throw new Error('Product must have id');
      const id = String(product.id);
      const existing = this.find(id);
      const q = Number(qty) || 1;
      if(existing){ existing.qty = clamp(existing.qty + q, 1, 9999); }
      else{
        this.items.push({ id, title: product.title || 'Untitled', price: Number(product.price) || 0, qty: clamp(q,1,9999), image: product.image||'', metadata: product.metadata||{} });
      }
      this.save();
      BlyntApp.emit('cart:changed', this.items);
      return this.find(id);
    },

    remove(id){
      const sid = String(id);
      const before = this.items.length;
      this.items = this.items.filter(i => String(i.id) !== sid);
      if(this.items.length !== before){ this.save(); BlyntApp.emit('cart:changed', this.items); return true; }
      return false;
    },

    updateQty(id, qty){
      const itm = this.find(id); if(!itm) return false;
      itm.qty = clamp(Number(qty) || 0, 0, 9999);
      if(itm.qty === 0) this.remove(id); else this.save();
      BlyntApp.emit('cart:changed', this.items);
      return true;
    },

    clear(){ this.items = []; this.coupon = null; this.save(); BlyntApp.emit('cart:changed', this.items); },

    setCoupon(c){ this.coupon = c; this.save(); BlyntApp.emit('cart:changed', this.items); },

    getTotals(options = {}){
      // options: taxRate, shippingCalculator (fn(total)->number)
      const taxRate = typeof options.taxRate === 'number' ? options.taxRate : DEFAULT_TAX_RATE;
      const shippingCalculator = typeof options.shippingCalculator === 'function' ? options.shippingCalculator : (() => DEFAULT_SHIPPING);

      const subtotal = this.items.reduce((s,it) => s + (Number(it.price||0) * Number(it.qty||0)), 0);
      let discount = 0;
      if(this.coupon){
        if(this.coupon.type === 'percent') discount = subtotal * (Number(this.coupon.value||0)/100);
        else discount = Number(this.coupon.value||0);
        discount = Math.min(discount, subtotal);
      }
      const afterDiscount = Math.max(0, subtotal - discount);
      const shipping = shippingCalculator(afterDiscount);
      const tax = afterDiscount * taxRate;
      const total = afterDiscount + tax + shipping;

      return {
        subtotal, discount, afterDiscount, tax, shipping, total
      };
    }
  };

  // ---------- Event Emitter (simple) ----------
  const Emitter = {
    _listeners: {},
    on(event, fn){ (this._listeners[event] = this._listeners[event] || []).push(fn); return () => this.off(event, fn); },
    off(event, fn){ if(!this._listeners[event]) return; this._listeners[event] = this._listeners[event].filter(f => f !== fn); },
    emit(event, payload){ (this._listeners[event] || []).forEach(fn => { try{ fn(payload); }catch(e){ console.error('Event handler error', e); } }); }
  };

  // ---------- UI Renderer ----------
  function defaultRenderCart(container){
    // Renders simple cart UI inside container element
    if(!container) return;
    const items = Cart.items;
    container.innerHTML = '';
    const list = document.createElement('div');
    list.className = 'blynt-cart-list';
    if(items.length === 0){ list.innerHTML = '<div class="blynt-empty">Your cart is empty</div>'; container.appendChild(list); return; }

    items.forEach(it => {
      const row = document.createElement('div'); row.className = 'blynt-cart-item';
      row.style.display = 'flex'; row.style.gap = '10px'; row.style.alignItems = 'center'; row.style.padding = '8px 0';
      row.innerHTML = `
        <div style="width:64px;height:64px;flex:0 0 64px;background:#f5f7fb;border-radius:8px;overflow:hidden"><img src="${escape(it.image)}" style="width:100%;height:100%;object-fit:cover"></div>
        <div style="flex:1">
          <div style="font-weight:700">${escape(it.title)}</div>
          <div style="font-size:13px;color:var(--muted)">${formatPrice(it.price)} × ${it.qty}</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
          <button data-remove-from-cart="${escape(it.id)}" title="Remove" style="background:transparent;border:none;color:var(--danger);cursor:pointer">Remove</button>
          <div style="display:flex;gap:6px;align-items:center">
            <button data-decrease-qty="${escape(it.id)}" style="width:28px;height:28px;border-radius:6px">−</button>
            <div style="min-width:28px;text-align:center">${it.qty}</div>
            <button data-increase-qty="${escape(it.id)}" style="width:28px;height:28px;border-radius:6px">+</button>
          </div>
        </div>
      `;
      list.appendChild(row);
    });

    // totals
    const totals = Cart.getTotals(window.BlyntApp.options);
    const totalsEl = document.createElement('div'); totalsEl.style.marginTop = '12px';
    totalsEl.innerHTML = `
      <div style="display:flex;justify-content:space-between"><div>Subtotal</div><div>${formatPrice(totals.subtotal)}</div></div>
      <div style="display:flex;justify-content:space-between"><div>Discount</div><div>-${formatPrice(totals.discount)}</div></div>
      <div style="display:flex;justify-content:space-between"><div>Shipping</div><div>${formatPrice(totals.shipping)}</div></div>
      <div style="display:flex;justify-content:space-between;font-weight:700;margin-top:8px"><div>Total</div><div>${formatPrice(totals.total)}</div></div>
      <div style="margin-top:10px;display:flex;gap:8px;justify-content:flex-end">
        <button id="blynt-checkout" class="btn">Checkout</button>
        <button id="blynt-clear" class="btn secondary">Clear</button>
      </div>
    `;
    container.appendChild(list);
    container.appendChild(totalsEl);

    // attach listeners for remove/increase/decrease
    container.querySelectorAll('[data-remove-from-cart]').forEach(btn => btn.addEventListener('click', (e)=>{ const id = btn.getAttribute('data-remove-from-cart'); Cart.remove(id); renderCart(container); }));
    container.querySelectorAll('[data-increase-qty]').forEach(btn => btn.addEventListener('click', (e)=>{ const id = btn.getAttribute('data-increase-qty'); Cart.add({id},1); renderCart(container); }));
    container.querySelectorAll('[data-decrease-qty]').forEach(btn => btn.addEventListener('click', (e)=>{ const id = btn.getAttribute('data-decrease-qty'); const found = Cart.find(id); if(found) Cart.updateQty(id, found.qty - 1); renderCart(container); }));

    // checkout & clear
    const checkoutBtn = container.querySelector('#blynt-checkout'); if(checkoutBtn) checkoutBtn.addEventListener('click', ()=>{ window.BlyntApp.checkout(); });
    const clearBtn = container.querySelector('#blynt-clear'); if(clearBtn) clearBtn.addEventListener('click', ()=>{ Cart.clear(); renderCart(container); });
  }

  function escape(s){ return (s||'').toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  // ---------- Product registry (optional) ----------
  const ProductRegistry = {
    map: {},
    register(product){ if(!product || !product.id) throw new Error('product must have id'); this.map[String(product.id)] = product; },
    get(id){ return this.map[String(id)]; }
  };

  // ---------- DOM bindings: add-to-cart buttons & cart rendering ----------
  function bindAddToCart(root){
    document.body.addEventListener('click', (e)=>{
      const btn = e.target.closest('[data-add-to-cart]');
      if(!btn) return;
      e.preventDefault();
      // data-add-to-cart may contain JSON payload or rely on product-id attribute
      const payloadAttr = btn.getAttribute('data-add-to-cart');
      let payload = null;
      if(payloadAttr){
        try{ payload = JSON.parse(payloadAttr); }catch(err){ /* not JSON */ }
      }
      const productId = btn.getAttribute('data-product-id');
      if(!payload && productId){ payload = ProductRegistry.get(productId) || { id: productId, title: btn.getAttribute('data-title') || 'Product', price: Number(btn.getAttribute('data-price')||0), image: btn.getAttribute('data-image')||'' } }
      if(!payload) return console.warn('Add to cart: missing product payload');
      const qty = Number(btn.getAttribute('data-qty')||1);
      Cart.add(payload, qty);
      // optional: animate or show mini cart
      BlyntApp.emit('cart:added', payload);
      // re-render cart if attached
      if(BlyntApp.cartContainer) renderCart(BlyntApp.cartContainer);
    });
  }

  function renderCart(container){
    if(!container) return;
    defaultRenderCart(container);
  }

  // ---------- Server sync helpers ----------
  async function syncCartToServer(endpoint = '/api/cart/sync'){
    try{
      const payload = { items: Cart.items, coupon: Cart.coupon, updatedAt: now() };
      const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), credentials: 'same-origin' });
      if(!res.ok) throw new Error('Sync failed: '+res.status);
      const data = await res.json(); BlyntApp.emit('cart:synced', data); return data;
    }catch(err){ console.warn('Cart sync failed', err); BlyntApp.emit('cart:sync:error', err); throw err; }
  }

  // ---------- Checkout helper ----------
  function checkout(){
    // Simple flow: POST cart to /api/checkout then redirect to payment
    // In production: handle authentication, token, server-side validation
    const payload = { items: Cart.items, coupon: Cart.coupon };
    BlyntApp.emit('checkout:start', payload);
    fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), credentials: 'same-origin' })
      .then(r => { if(!r.ok) throw new Error('Checkout failed'); return r.json(); })
      .then(data => {
        BlyntApp.emit('checkout:success', data);
        // expect server to return {redirectUrl: 'https://...'} or order id
        if(data && data.redirectUrl) window.location.href = data.redirectUrl;
        else if(data && data.orderId) window.location.href = '/order/' + encodeURIComponent(data.orderId);
        else window.location.href = '/thank-you';
      })
      .catch(err => { BlyntApp.emit('checkout:error', err); alert('Checkout failed: '+err.message); });
  }

  // ---------- Initialization & public API ----------
  const BlyntApp = {
    options: { taxRate: DEFAULT_TAX_RATE, shippingCalculator: () => DEFAULT_SHIPPING },
    cart: Cart,
    registerProduct: (p) => ProductRegistry.register(p),
    on: (ev, fn) => Emitter.on(ev, fn),
    off: (ev, fn) => Emitter.off(ev, fn),
    emit: (ev, payload) => Emitter.emit(ev, payload),

    init(opts = {}){
      // opts: { cartSelector, bindAddButtons, taxRate, shippingCalculator }
      if(opts.taxRate != null) this.options.taxRate = opts.taxRate;
      if(typeof opts.shippingCalculator === 'function') this.options.shippingCalculator = opts.shippingCalculator;
      Cart.load();
      // cart container
      this.cartContainer = document.querySelector(opts.cartSelector || '#cart');
      if(this.cartContainer) renderCart(this.cartContainer);
      // Bind add-to-cart buttons
      if(opts.bindAddButtons !== false) bindAddToCart(document.body);
      // Re-render on cart change
      this.on('cart:changed', ()=>{ if(this.cartContainer) renderCart(this.cartContainer); });
      return this;
    },

    // convenience wrappers
    addToCart(product, qty){ return Cart.add(product, qty); },
    removeFromCart(id){ return Cart.remove(id); },
    updateQty(id, qty){ return Cart.updateQty(id, qty); },
    getTotals(){ return Cart.getTotals(this.options); },
    applyCoupon(code){
      // basic coupon validation — in real app validate via server
      if(!code) return false;
      // example: 'SAVE10' -> 10% off
      if(code.match(/^SAVE(\d+)$/i)){ const pct = Number(RegExp.$1); Cart.setCoupon({ code, type:'percent', value:pct }); return true; }
      if(code.match(/^FLAT(\d+)$/i)){ const val = Number(RegExp.$1); Cart.setCoupon({ code, type:'fixed', value:val }); return true; }
      return false;
    },
    clearCart(){ Cart.clear(); },
    syncCartToServer,
    checkout
  };

  // expose globally
  window.BlyntApp = BlyntApp;

  // auto-init when DOM ready
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=> BlyntApp.init()); else BlyntApp.init();

})(window, document);
