const DB = require('./database');
await DB.init();
await DB.migrate();
const user = await DB.createUser({ role:'customer', email:'a@b.com', passwordHash:'<bcrypt-hash>' });

