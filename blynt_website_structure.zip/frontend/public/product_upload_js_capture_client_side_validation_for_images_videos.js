/*
  product-upload.js
  - Client-side capture, validation, preview and upload helpers for product images and videos.
  - Exposes a global `BlyntUpload` object with methods to initialize upload widgets and to upload files.
  - Features:
    * Drag & drop + file picker support
    * Validation: file types, max counts, individual max sizes, image dimension checks
    * Image client-side resizing (JPEG/PNG/WebP) to reduce upload size
    * Video basic validation (type, size, duration if available)
    * Progress callbacks and abort support

  Usage example:
    BlyntUpload.init({
      imageInput: document.getElementById('imageInput'),
      imageDropzone: document.getElementById('imageUploader'),
      imagePreviewContainer: document.getElementById('imageThumbs'),
      maxImages: 8,
      maxImageSize: 5 * 1024 * 1024, // 5MB
      maxImageWidth: 2000,
      maxImageHeight: 2000,
      onChange: (images) => { /* update UI */ },
    });

  Notes:
  - This file focuses on client-side UX and validation. Server endpoints for direct uploads should accept multipart/form-data.
  - For production, consider server-side validation, virus scanning, and signed uploads (S3/Cloud storage) to avoid passing large files through your app server.
*/

(function(window, document){
  'use strict';

  // --- Defaults ---
  const DEFAULTS = {
    image: {
      maxCount: 8,
      maxSize: 5 * 1024 * 1024, // 5MB
      allowedTypes: ['image/jpeg','image/png','image/webp'],
      maxWidth: 3000,
      maxHeight: 3000,
      resizeToWidth: 1600 // if image wider than this, resize to this width keeping aspect ratio
    },
    video: {
      maxCount: 2,
      maxSize: 50 * 1024 * 1024, // 50MB
      allowedTypes: ['video/mp4','video/webm','video/quicktime'],
      maxDuration: 300 // seconds (5 minutes)
    }
  };

  // --- Helpers ---
  function isImageType(type){ return DEFAULTS.image.allowedTypes.includes(type); }
  function isVideoType(type){ return DEFAULTS.video.allowedTypes.includes(type); }
  function bytes(n){ return (n/1024/1024).toFixed(2) + ' MB'; }

  function createEl(tag, attrs){ const el = document.createElement(tag); if(attrs) Object.keys(attrs).forEach(k=>el.setAttribute(k, attrs[k])); return el; }

  // Read image metadata and possibly downscale using canvas
  async function resizeImageFile(file, targetWidth){
    // returns a Blob (JPEG) with quality reduction
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth; const h = img.naturalHeight;
    if(w <= targetWidth) return file; // no need to resize

    const ratio = targetWidth / w;
    const nw = Math.round(w * ratio); const nh = Math.round(h * ratio);

    const canvas = document.createElement('canvas');
    canvas.width = nw; canvas.height = nh;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, nw, nh);

    // Convert to blob (JPEG) — this reduces file size. Use 0.85 quality.
    return await new Promise((resolve) => {
      canvas.toBlob((blob) => {
        // Preserve original file name but change extension to jpg
        const newFile = blob ? new File([blob], (file.name.replace(/\.[^.]+$/, '') + '.jpg'), { type: 'image/jpeg' }) : file;
        resolve(newFile);
      }, 'image/jpeg', 0.85);
    });
  }

  function loadImageFromFile(file){
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = ()=>{ URL.revokeObjectURL(url); resolve(img); };
      img.onerror = (e)=>{ URL.revokeObjectURL(url); reject(new Error('Failed to load image')); };
      img.src = url;
    });
  }

  async function getVideoDuration(file){
    return new Promise((resolve, reject) => {
      try{
        const url = URL.createObjectURL(file);
        const v = document.createElement('video');
        v.preload = 'metadata';
        v.onloadedmetadata = function(){
          URL.revokeObjectURL(url);
          const duration = v.duration; v.remove(); resolve(duration);
        };
        v.onerror = function(){ URL.revokeObjectURL(url); v.remove(); resolve(null); };
        v.src = url;
      }catch(e){ resolve(null); }
    });
  }

  // Upload helper with progress and abort (uses XMLHttpRequest for progress)
  function uploadFormData(url, formData, onProgress, signal){
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.withCredentials = true;
      xhr.upload.onprogress = function(ev){ if(ev.lengthComputable && typeof onProgress === 'function') onProgress(ev.loaded, ev.total); };
      xhr.onload = function(){ if(xhr.status >=200 && xhr.status < 300){ try{ const json = JSON.parse(xhr.responseText); resolve(json);}catch(e){ resolve(xhr.responseText); } } else { reject(new Error('Upload failed: '+xhr.status+' '+xhr.statusText)); } };
      xhr.onerror = function(){ reject(new Error('Upload network error')); };
      if(signal){ signal.addEventListener('abort', ()=>{ xhr.abort(); reject(new Error('Upload aborted')); }); }
      xhr.send(formData);
    });
  }

  // --- Widget logic ---
  function buildPreviewImage(file){
    const wrap = createEl('div'); wrap.className = 'thumb';
    const img = createEl('img'); img.src = URL.createObjectURL(file); img.onload = ()=> URL.revokeObjectURL(img.src);
    const rem = createEl('button'); rem.type='button'; rem.className='remove'; rem.textContent='×';
    wrap.appendChild(img); wrap.appendChild(rem);
    return {wrap, rem};
  }

  function buildPreviewVideo(file){
    const wrap = createEl('div'); wrap.className = 'thumb';
    const vid = createEl('video'); vid.src = URL.createObjectURL(file); vid.controls = true; vid.onloadeddata = ()=> URL.revokeObjectURL(vid.src);
    const rem = createEl('button'); rem.type='button'; rem.className='remove'; rem.textContent='×';
    wrap.appendChild(vid); wrap.appendChild(rem);
    return {wrap, rem};
  }

  // --- Main API ---
  const BlyntUpload = {
    instances: [],

    init(opts){
      // opts: { imageInput, imageDropzone, imagePreviewContainer, videoInput, videoDropzone, videoPreviewContainer, callbacks... }
      const instance = Object.assign({
        images: [], videos: [],
        options: { image: Object.assign({}, DEFAULTS.image), video: Object.assign({}, DEFAULTS.video) },
        callbacks: {}
      }, opts || {});

      // merge custom options
      if(opts && opts.options){ if(opts.options.image) Object.assign(instance.options.image, opts.options.image); if(opts.options.video) Object.assign(instance.options.video, opts.options.video); }

      // Bind image input and dropzone
      if(instance.imageInput){
        instance.imageInput.addEventListener('change', (e)=> handleImageFiles(instance, Array.from(e.target.files||[])));
      }
      if(instance.imageDropzone){
        instance.imageDropzone.addEventListener('dragover', (e)=>{ e.preventDefault(); instance.imageDropzone.classList.add('dragover'); });
        instance.imageDropzone.addEventListener('dragleave', (e)=>{ instance.imageDropzone.classList.remove('dragover'); });
        instance.imageDropzone.addEventListener('drop', (e)=>{ e.preventDefault(); instance.imageDropzone.classList.remove('dragover'); handleImageFiles(instance, Array.from(e.dataTransfer.files||[])); });
      }

      // Bind video input and dropzone
      if(instance.videoInput){
        instance.videoInput.addEventListener('change', (e)=> handleVideoFiles(instance, Array.from(e.target.files||[])));
      }
      if(instance.videoDropzone){
        instance.videoDropzone.addEventListener('dragover', (e)=>{ e.preventDefault(); instance.videoDropzone.classList.add('dragover'); });
        instance.videoDropzone.addEventListener('dragleave', (e)=>{ instance.videoDropzone.classList.remove('dragover'); });
        instance.videoDropzone.addEventListener('drop', (e)=>{ e.preventDefault(); instance.videoDropzone.classList.remove('dragover'); handleVideoFiles(instance, Array.from(e.dataTransfer.files||[])); });
      }

      // store instance
      this.instances.push(instance);
      return instance;
    },

    async upload(files, url, onProgress, signal){
      // files: { images: [File], videos: [File] }
      const fd = new FormData();
      (files.images||[]).forEach((f,i)=> fd.append('images[]', f, f.name));
      (files.videos||[]).forEach((v,i)=> fd.append('videos[]', v, v.name));
      return uploadFormData(url, fd, onProgress, signal);
    }
  };

  // --- Internal handlers ---
  async function handleImageFiles(instance, fileList){
    const opts = instance.options.image;
    for(const f of fileList){
      if(instance.images.length >= opts.maxCount){ invokeCallback(instance, 'onError', new Error('Maximum images reached')); break; }
      if(!isImageType(f.type)) { invokeCallback(instance, 'onError', new Error('Unsupported image type: '+f.type)); continue; }
      if(f.size > opts.maxSize) { invokeCallback(instance, 'onError', new Error('Image too large: '+bytes(f.size))); continue; }

      // check dimensions (load image)
      let img;
      try{ img = await loadImageFromFile(f); }catch(e){ invokeCallback(instance, 'onError', new Error('Failed to read image')); continue; }
      if((opts.maxWidth && img.naturalWidth > opts.maxWidth) || (opts.maxHeight && img.naturalHeight > opts.maxHeight)){
        // allow but warn; optional: reject
        invokeCallback(instance, 'onWarning', 'Image dimensions exceed recommended maximum: '+img.naturalWidth+'x'+img.naturalHeight);
      }

      // optional resize
      let uploadFile = f;
      if(opts.resizeToWidth && img.naturalWidth > opts.resizeToWidth){
        try{ uploadFile = await resizeImageFile(f, opts.resizeToWidth); }
        catch(e){ console.warn('Resize failed', e); }
      }

      instance.images.push(uploadFile);
      renderImagePreview(instance, uploadFile);
      invokeCallback(instance, 'onChange', { images: instance.images, videos: instance.videos });
    }
  }

  async function handleVideoFiles(instance, fileList){
    const opts = instance.options.video;
    for(const f of fileList){
      if(instance.videos.length >= opts.maxCount){ invokeCallback(instance, 'onError', new Error('Maximum videos reached')); break; }
      if(!isVideoType(f.type)) { invokeCallback(instance, 'onError', new Error('Unsupported video type: '+f.type)); continue; }
      if(f.size > opts.maxSize) { invokeCallback(instance, 'onError', new Error('Video too large: '+bytes(f.size))); continue; }

      // check duration
      const duration = await getVideoDuration(f);
      if(duration && opts.maxDuration && duration > opts.maxDuration){ invokeCallback(instance, 'onError', new Error('Video too long: '+Math.round(duration)+'s')); continue; }

      // accept
      instance.videos.push(f);
      renderVideoPreview(instance, f);
      invokeCallback(instance, 'onChange', { images: instance.images, videos: instance.videos });
    }
  }

  function renderImagePreview(instance, file){
    if(!instance.imagePreviewContainer) return;
    const { wrap, rem } = buildPreviewImage(file);
    rem.addEventListener('click', ()=>{ const idx = instance.images.indexOf(file); if(idx>=0) instance.images.splice(idx,1); wrap.remove(); invokeCallback(instance,'onChange',{images:instance.images,videos:instance.videos}); });
    instance.imagePreviewContainer.appendChild(wrap);
  }

  function renderVideoPreview(instance, file){
    if(!instance.videoPreviewContainer) return;
    const { wrap, rem } = buildPreviewVideo(file);
    rem.addEventListener('click', ()=>{ const idx = instance.videos.indexOf(file); if(idx>=0) instance.videos.splice(idx,1); wrap.remove(); invokeCallback(instance,'onChange',{images:instance.images,videos:instance.videos}); });
    instance.videoPreviewContainer.appendChild(wrap);
  }

  function invokeCallback(instance, name, payload){
    if(instance && instance.callbacks && typeof instance.callbacks[name] === 'function'){
      try{ instance.callbacks[name](payload); }catch(e){ console.error('Callback error', e); }
    }
  }

  // expose
  window.BlyntUpload = BlyntUpload;

})(window, document);
