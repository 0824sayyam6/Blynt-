// api-routes.js
// Express router factory for Blynt API endpoints (auth, products, orders, payments)
// Export: createApiRouter({ db, upload, config }) -> express.Router()

const express = require('express');
const crypto = require('crypto');

function createApiRouter(opts = {}){
  const router = express.Router();
  const db = opts.db || { users: [], products: [], categories: [], orders: [], carts: {} };
  const upload = opts.upload; // multer instance (optional) for file uploads
  const CONFIG = Object.assign({ ADMIN_EMAIL: 'Blynt321@gmail.com', ADMIN_PASSWORD: '8724166shabbir', WEBHOOK_SECRET: 'change_me' }, opts.config || {});

  // helpers
  function generateId(prefix=''){ return prefix + crypto.randomBytes(6).toString('hex'); }
  function now(){ return new Date().toISOString(); }
  function findUserByEmail(email){ return db.users.find(u => u.email.toLowerCase() === (email||'').toLowerCase()); }
  function createUser({ role, email, password, name }){
    if(findUserByEmail(email)) throw new Error('Email already registered');
    const user = { id: generateId('u_'), role, email, passwordHash: password, name: name||'', createdAt: now() };
    db.users.push(user); return user;
  }

  // --- Middleware (simple/demo) ---
  function requireAdmin(req, res, next){
    const adminHeader = req.get('x-admin-secret');
    if(adminHeader && adminHeader === CONFIG.ADMIN_PASSWORD) return next();
    const auth = (req.headers.authorization||'');
    if(auth.startsWith('Basic ')){
      try{ const decoded = Buffer.from(auth.split(' ')[1], 'base64').toString(); const [email, pass] = decoded.split(':'); if(email === CONFIG.ADMIN_EMAIL && pass === CONFIG.ADMIN_PASSWORD) return next(); }catch(e){}
    }
    return res.status(401).json({ error: 'admin auth required' });
  }
  function requireUser(req, res, next){ const uid = req.get('x-user-id'); if(!uid) return res.status(401).json({ error: 'missing x-user-id header' }); const u = db.users.find(x => x.id === uid); if(!u) return res.status(403).json({ error: 'user not found' }); req.currentUser = u; next(); }
  function requireSeller(req, res, next){ const uid = req.get('x-user-id'); if(!uid) return res.status(401).json({ error: 'missing x-user-id header' }); const u = db.users.find(x => x.id === uid && x.role === 'seller'); if(!u) return res.status(403).json({ error: 'seller role required' }); req.currentUser = u; next(); }

  // --- Auth routes ---
  // Register (customer or seller). Admin cannot register here.
  router.post('/auth/register', express.json(), (req, res) => {
    try{
      const { role, email, password } = req.body || {};
      if(!role || !email || !password) return res.status(400).json({ success:false, message: 'role, email and password required' });
      if(role === 'admin') return res.status(400).json({ success:false, message: 'admin cannot register' });
      // basic validations
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ success:false, message:'invalid email' });
      if(String(password).length < 6) return res.status(400).json({ success:false, message:'password too short' });
      const user = createUser({ role, email, password });
      return res.json({ success:true, userId: user.id, message: 'registered' });
    }catch(err){ return res.status(400).json({ success:false, message: err.message }); }
  });

  // Login
  router.post('/auth/login', express.json(), (req, res) => {
    try{
      const { role, email, password } = req.body || {};
      if(!email || !password) return res.status(400).json({ success:false, message:'email and password required' });
      if(role === 'admin'){
        if(email.toLowerCase() === CONFIG.ADMIN_EMAIL.toLowerCase() && password === CONFIG.ADMIN_PASSWORD) return res.json({ success:true, role:'admin', redirect:'/admin/dashboard' });
        else return res.status(401).json({ success:false, message:'invalid admin credentials' });
      }
      const user = findUserByEmail(email);
      if(!user || user.role !== role) return res.status(401).json({ success:false, message:'invalid credentials' });
      if(user.passwordHash !== password) return res.status(401).json({ success:false, message:'invalid credentials' });
      return res.json({ success:true, role:user.role, userId:user.id });
    }catch(err){ return res.status(500).json({ success:false, message:'login failed' }); }
  });

  // --- Categories ---
  router.get('/categories', (req, res) => res.json(db.categories || []));
  router.post('/categories', requireAdmin, upload ? upload.single('image') : (req,res,next)=>next(), (req,res)=>{
    try{
      const { title, description } = req.body || {};
      if(!title) return res.status(400).json({ success:false, message:'title required' });
      const imageUrl = req.file ? '/uploads/' + req.file.filename : null;
      const cat = { id: generateId('cat_'), title, description: description||'', imageUrl, createdAt: now() };
      db.categories.push(cat);
      return res.json({ success:true, category:cat });
    }catch(err){ return res.status(500).json({ success:false, message: err.message }); }
  });

  // --- Products ---
  // public listing
  router.get('/products', (req, res) => {
    const limit = parseInt(req.query.limit || '24', 10);
    const list = (db.products || []).filter(p => p.status === 'published').slice(0, limit);
    return res.json(list);
  });
  router.get('/products/:id', (req, res) => { const p = (db.products || []).find(x => x.id === req.params.id); if(!p) return res.status(404).json({ success:false, message:'product not found' }); return res.json(p); });

  // seller create product (multipart)
  if(upload){
    router.post('/seller/products', requireSeller, upload.fields([{ name:'images[]' }, { name:'videos[]' }]), (req,res)=>{
      try{
        const seller = req.currentUser; const body = req.body || {};
        const title = body.title || body.name; if(!title) return res.status(400).json({ success:false, message:'title required' });
        const price = Number(body.price || 0); const stock = Number(body.stock || 0);
        const images = (req.files && req.files['images[]']) ? req.files['images[]'].map(f=>'/uploads/'+f.filename) : [];
        const videos = (req.files && req.files['videos[]']) ? req.files['videos[]'].map(f=>'/uploads/'+f.filename) : [];
        const prod = { id: generateId('p_'), sellerId: seller.id, title, price, description: body.description||'', images, videos, stock, sku: body.sku||'', category: body.category||'', tags: (body.tags||'').split(',').map(t=>t.trim()).filter(Boolean), createdAt: now(), status: body.status||'draft', visibility: body.visibility||'public' };
        db.products.push(prod);
        return res.json({ success:true, product:prod });
      }catch(err){ console.error(err); return res.status(500).json({ success:false, message:err.message }); }
    });
  } else {
    // if multer not provided, accept JSON (no files)
    router.post('/seller/products', requireSeller, express.json(), (req,res)=>{
      try{
        const seller = req.currentUser; const body = req.body || {};
        const title = body.title || body.name; if(!title) return res.status(400).json({ success:false, message:'title required' });
        const prod = Object.assign({ id: generateId('p_'), sellerId: seller.id, createdAt: now(), status:'draft' }, body);
        db.products.push(prod); return res.json({ success:true, product:prod });
      }catch(err){ return res.status(500).json({ success:false, message:err.message }); }
    });
  }

  // --- Cart sync ---
  router.post('/cart/sync', requireUser, express.json(), (req, res) => {
    const user = req.currentUser; const payload = req.body || {};
    db.carts[user.id] = { items: payload.items || [], coupon: payload.coupon || null, updatedAt: now() };
    return res.json({ success:true });
  });

  // --- Checkout ---
  router.post('/checkout', requireUser, express.json(), (req,res)=>{
    try{
      const user = req.currentUser; const { items, coupon } = req.body || {};
      if(!items || !Array.isArray(items) || items.length===0) return res.status(400).json({ success:false, message:'cart empty' });
      const subtotal = items.reduce((s,it) => s + (Number(it.price||0) * Number(it.qty||0)), 0);
      const shipping = 5.0; const tax = subtotal * 0.12; let discount = 0; if(coupon){ if(coupon.type==='percent') discount = subtotal*(Number(coupon.value||0)/100); else discount = Number(coupon.value||0); }
      const total = Math.max(0, subtotal - discount) + tax + shipping;
      const order = { id: generateId('o_'), userId: user.id, items, subtotal, discount, tax, shipping, total, status:'pending', createdAt: now() };
      db.orders.push(order);
      return res.json({ success:true, orderId: order.id, redirectUrl: `/mock-pay?orderId=${order.id}` });
    }catch(err){ console.error(err); return res.status(500).json({ success:false, message:'checkout failed' }); }
  });

  // --- Webhooks (payment) ---
  // expects raw body; callers should mount express.raw({ type: 'application/json' }) before router or use this route directly
  router.post('/webhooks/payment', (req, res) => {
    try{
      const sig = req.get('x-signature') || '';
      const bodyBuf = req.body; // may be raw buffer or parsed object
      let raw;
      if(Buffer.isBuffer(bodyBuf)) raw = bodyBuf; else raw = Buffer.from(JSON.stringify(bodyBuf));
      const computed = crypto.createHmac('sha256', CONFIG.WEBHOOK_SECRET).update(raw).digest('hex');
      if(!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(computed))){ console.warn('Webhook signature mismatch'); return res.status(400).send('invalid signature'); }
      const payload = typeof bodyBuf === 'object' ? bodyBuf : JSON.parse(raw.toString('utf8'));
      if(payload.event === 'payment.succeeded'){ const order = db.orders.find(o => o.id === payload.orderId); if(order){ order.status='paid'; order.paidAt = now(); } }
      return res.json({ received:true });
    }catch(err){ console.error('webhook error', err); return res.status(500).send('webhook error'); }
  });

  // --- Admin helpers ---
  router.get('/admin/products', requireAdmin, (req,res)=> res.json(db.products));
  router.get('/admin/users', requireAdmin, (req,res) => res.json(db.users));
  router.get('/admin/orders', requireAdmin, (req,res) => res.json(db.orders));

  return router;
}

module.exports = { createApiRouter };
